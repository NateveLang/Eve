from eve.app import main
main()
